import './App.css'

function App() {
  return (
    <div className='w-full h-screen flex flex-col items-center justify-center'>

    </div>
  )
}

export default App
